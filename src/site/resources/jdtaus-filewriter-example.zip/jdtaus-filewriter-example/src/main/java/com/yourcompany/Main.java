package com.yourcompany;

import java.io.File;
import java.math.BigInteger;
import java.util.Currency;
import java.util.Date;
import org.jdtaus.banking.AlphaNumericText27;
import org.jdtaus.banking.Bankleitzahl;
import org.jdtaus.banking.Kontonummer;
import org.jdtaus.banking.Textschluessel;
import org.jdtaus.banking.TextschluesselVerzeichnis;
import org.jdtaus.banking.dtaus.Header;
import org.jdtaus.banking.dtaus.LogicalFile;
import org.jdtaus.banking.dtaus.LogicalFileType;
import org.jdtaus.banking.dtaus.PhysicalFile;
import org.jdtaus.banking.dtaus.PhysicalFileFactory;
import org.jdtaus.banking.dtaus.Transaction;
import org.jdtaus.core.container.ContainerFactory;

public class Main
{

    public static void main( String[] args ) throws Exception
    {
        final PhysicalFileFactory physicalFileFactory =
            (PhysicalFileFactory) ContainerFactory.getContainer().getObject( PhysicalFileFactory.class );

        final TextschluesselVerzeichnis textschluesselVerzeichnis =
            (TextschluesselVerzeichnis) ContainerFactory.getContainer().getObject( TextschluesselVerzeichnis.class );

        final Textschluessel textschluessel = textschluesselVerzeichnis.getTextschluessel( 51, 0, new Date() );
        final Header header = new Header();
        header.setAccount( Kontonummer.valueOf( new Long( 1111111111L ) ) );
        header.setBank( Bankleitzahl.valueOf( new Integer( 88888888 ) ) );
        header.setCreateDate( new Date() );
        header.setCurrency( Currency.getInstance( "EUR" ) );
        header.setCustomer( AlphaNumericText27.parse( "TEST NAME" ) );
        header.setType( LogicalFileType.GK );

        final Transaction transaction = new Transaction();
        transaction.setAmount( BigInteger.ONE );
        transaction.setCurrency( Currency.getInstance( "EUR" ) );
        transaction.setExecutiveAccount( Kontonummer.valueOf( new Long( 1111111111L ) ) );
        transaction.setExecutiveBank( Bankleitzahl.valueOf( new Integer( 88888888 ) ) );
        transaction.setExecutiveName( AlphaNumericText27.parse( "TEST NAME" ) );
        transaction.setTargetAccount( Kontonummer.valueOf( new Long( 11111111L ) ) );
        transaction.setTargetBank( Bankleitzahl.valueOf( new Integer( 88888888 ) ) );
        transaction.setTargetName( AlphaNumericText27.valueOf( "TEST NAME" ) );
        transaction.setType( textschluessel );

        final File tmpFile = File.createTempFile( "jdtaus-test", ".dta" );
        final PhysicalFile pFile = physicalFileFactory.createPhysicalFile( tmpFile, PhysicalFileFactory.FORMAT_DISK );

        final LogicalFile lFile = pFile.addLogicalFile( header );
        for ( int i = 10000; i > 0; i-- )
        {
            lFile.addTransaction( transaction );
        }

        pFile.commit();

        final StringBuffer stringBuffer =
            new StringBuffer( 1024 ).append( "\n\n\n\n" ).append( tmpFile.getAbsolutePath() ).append( '\n' );

        System.out.println( stringBuffer.toString() );
        System.exit( 0 );
    }

}
